// Google Apps Script - Code.gs
// 1) أنشئ Google Sheet ثم افتح Extensions > Apps Script.
// 2) الصق هذا الملف، واحفظه.
// 3) انشره Deploy > New deployment > Web app، وحدد Execute as: Me.
// 4) انسخ رابط /exec إلى لوحة الإدارة في المنصة.
const SHEET_NAME = "نتائج الطلاب";
function doPost(e) {
  const data = JSON.parse(e.postData.contents || "{}");
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME);
    sh.appendRow(["التاريخ","اسم الطالب","الصف","المدرسة","النشاط","الإجابة 1","الإجابة 2","الدرجة"]);
  }
  sh.appendRow([
    new Date(), data.student || "", data.grade || "", data.school || "",
    data.activity || "", data.answer1 || "", data.answer2 || "", data.score || ""
  ]);
  return ContentService.createTextOutput(JSON.stringify({ok:true}))
    .setMimeType(ContentService.MimeType.JSON);
}
function doGet() {
  return ContentService.createTextOutput("منصة التعلم الدراسي - الربط يعمل")
    .setMimeType(ContentService.MimeType.TEXT);
}